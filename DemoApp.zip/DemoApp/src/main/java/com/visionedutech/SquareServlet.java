package com.visionedutech;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SquareServlet extends HttpServlet 
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		int i = 0;
		/*
		 * HttpSession session = req.getSession(); int i = (int)
		 * session.getAttribute("k");
		 */
		//int i = (int) req.getAttribute("k");
		//int i= Integer.parseInt(req.getParameter("k")); 
		Cookie cookie[] = req.getCookies();
		for(Cookie c : cookie)
		{
			if(c.getName().equals("k"))
			{
				i =Integer.parseInt(c.getValue());
			}
		}
		 i = i * i;
		 
		PrintWriter pw = res.getWriter();
		pw.println("<h1>The result is </h1>"+i);
	}
}
