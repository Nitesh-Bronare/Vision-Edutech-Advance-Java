package com.visionedutech;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException 
	{
	ServletContext ctx = req.getServletContext();	
	String str = ctx.getInitParameter("name");
	PrintWriter pw = res.getWriter();
	pw.print("<h1> Hello </h1>"+str);
	
	ServletConfig cfg = getServletConfig();
	String str1 = cfg.getInitParameter("Address");
	pw.println("<h1> Hello </h1>"+str1);
	}
}
